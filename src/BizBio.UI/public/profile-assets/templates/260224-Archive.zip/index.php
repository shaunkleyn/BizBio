<?php
$dir = __DIR__;
$self = basename(__FILE__);

$files = array_values(array_filter(scandir($dir), function($f) use ($self, $dir) {
    if ($f === '.' || $f === '..') return false;
    if (strtolower($f) === strtolower($self)) return false;
    if (!preg_match('/\.html?$/i', $f)) return false;
    if (stripos($f, 'index.') === 0) return false;
    return is_file($dir . '/' . $f);
}));

sort($files, SORT_NATURAL | SORT_FLAG_CASE);

$templateStyles = [
    '01' => ['name' => 'Minimalist Clean', 'tags' => ['minimal', 'clean', 'modern']],
    '02' => ['name' => 'Corporate Professional', 'tags' => ['corporate', 'business', 'formal']],
    '03' => ['name' => 'Bold Creative', 'tags' => ['creative', 'bold', 'colorful']],
    '04' => ['name' => 'Dark Elegant', 'tags' => ['dark', 'elegant', 'luxury']],
    '05' => ['name' => 'Gradient Modern', 'tags' => ['gradient', 'modern', 'vibrant']],
    '06' => ['name' => 'Glassmorphism', 'tags' => ['glass', 'blur', 'modern']],
    '07' => ['name' => 'Neumorphism', 'tags' => ['soft', '3d', 'minimal']],
    '08' => ['name' => 'Split Screen', 'tags' => ['split', 'two-tone', 'modern']],
    '09' => ['name' => 'Photo Centric', 'tags' => ['photo', 'hero', 'visual']],
    '10' => ['name' => 'Tech Futuristic', 'tags' => ['tech', 'cyber', 'neon']],
    '11' => ['name' => 'Organic Nature', 'tags' => ['nature', 'organic', 'green']],
    '12' => ['name' => 'Retro Vintage', 'tags' => ['retro', 'vintage', 'classic']],
    '13' => ['name' => 'Social Media', 'tags' => ['social', 'influencer', 'stats']],
    '14' => ['name' => 'Card Stack', 'tags' => ['stacked', 'layered', 'purple']],
    '15' => ['name' => 'Compact Rounded', 'tags' => ['compact', 'rounded', 'warm']],
    '16' => ['name' => 'Mono Elegant', 'tags' => ['mono', 'black', 'minimal']],
    '17' => ['name' => 'Vibrant Gradient', 'tags' => ['vibrant', 'colorful', 'fun']],
    '18' => ['name' => 'Professional Blue', 'tags' => ['blue', 'corporate', 'trust']],
    '19' => ['name' => 'Soft Pastel', 'tags' => ['pastel', 'soft', 'feminine']],
    '20' => ['name' => 'Executive Premium', 'tags' => ['executive', 'premium', 'gold']],
    '21' => ['name' => 'Navy Corporate Wave', 'tags' => ['navy', 'corporate', 'wave']],
    '22' => ['name' => 'Gradient Wave Stats', 'tags' => ['gradient', 'wave', 'stats']],
    '23' => ['name' => 'Glassmorphism Blob', 'tags' => ['glass', 'blob', 'colorful']],
    '24' => ['name' => 'Dark Neumorphic', 'tags' => ['dark', 'neumorphic', 'contact']],
    '25' => ['name' => 'Designer Portfolio', 'tags' => ['designer', 'portfolio', 'stats']],
    '26' => ['name' => 'Teal Profile Stats', 'tags' => ['teal', 'profile', 'stats']],
    '27' => ['name' => 'Creative Wave Header', 'tags' => ['creative', 'wave', 'artistic']],
    '28' => ['name' => 'Photo Hero Influencer', 'tags' => ['photo', 'hero', 'influencer']],
    '29' => ['name' => 'Blue Dashboard', 'tags' => ['blue', 'dashboard', 'mobile']],
    '30' => ['name' => 'Corporate Logo Card', 'tags' => ['corporate', 'logo', 'green']]
];

function getTemplateInfo($file, $styles) {
    if (preg_match('/^(\d+)-(.+)\.html?$/i', $file, $match)) {
        $num = $match[1];
        if (isset($styles[$num])) {
            return [
                'num' => $num,
                'name' => $styles[$num]['name'],
                'tags' => $styles[$num]['tags']
            ];
        }
    }
    return [
        'num' => '?',
        'name' => preg_replace('/\.html?$/i', '', $file),
        'tags' => []
    ];
}

$templateCount = count($files);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Business Card Templates | BizBio</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #0f172a;
            min-height: 100vh;
            color: #fff;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            padding: 40px 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background:
                radial-gradient(circle at 20% 50%, rgba(59, 130, 246, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 50%, rgba(168, 85, 247, 0.15) 0%, transparent 50%);
            pointer-events: none;
        }

        .header-content {
            position: relative;
            z-index: 1;
            max-width: 800px;
            margin: 0 auto;
        }

        .logo {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .logo-text {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .header h1 {
            font-size: 42px;
            font-weight: 800;
            margin-bottom: 12px;
            line-height: 1.2;
        }

        .header p {
            font-size: 18px;
            color: #94a3b8;
            max-width: 600px;
            margin: 0 auto 24px;
            line-height: 1.6;
        }

        .stats {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin-top: 24px;
        }

        .stat {
            text-align: center;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-label {
            font-size: 14px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 4px;
        }

        /* Search & Filter */
        .controls {
            max-width: 1600px;
            margin: 0 auto;
            padding: 30px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .search-box {
            position: relative;
            flex: 1;
            max-width: 400px;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 50px;
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            color: #fff;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .search-box input::placeholder {
            color: #64748b;
        }

        .search-box i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 16px;
        }

        .view-toggle {
            display: flex;
            gap: 8px;
        }

        .view-btn {
            width: 44px;
            height: 44px;
            border-radius: 10px;
            background: #1e293b;
            border: 1px solid #334155;
            color: #64748b;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .view-btn:hover, .view-btn.active {
            background: #3b82f6;
            border-color: #3b82f6;
            color: #fff;
        }

        /* Grid */
        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 0 40px 60px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 24px;
        }

        .grid.large {
            grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
        }

        /* Card */
        .card {
            background: linear-gradient(145deg, #1e293b 0%, #1a2234 100%);
            border-radius: 20px;
            overflow: hidden;
            border: 1px solid #334155;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }

        .card:hover {
            transform: translateY(-8px);
            border-color: #3b82f6;
            box-shadow:
                0 20px 40px rgba(0, 0, 0, 0.3),
                0 0 0 1px rgba(59, 130, 246, 0.5);
        }

        .card.hidden {
            display: none;
        }

        .card-header {
            padding: 20px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #334155;
        }

        .card-info {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .card-number {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: 700;
        }

        .card-title h3 {
            font-size: 15px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 2px;
        }

        .card-title span {
            font-size: 12px;
            color: #64748b;
        }

        .card-actions {
            display: flex;
            gap: 8px;
        }

        .card-btn {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            background: #0f172a;
            border: 1px solid #334155;
            color: #94a3b8;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .card-btn:hover {
            background: #3b82f6;
            border-color: #3b82f6;
            color: #fff;
        }

        .card-btn.primary {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-color: transparent;
            color: #fff;
        }

        .card-btn.primary:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
        }

        .preview-frame {
            position: relative;
            height: 480px;
            background: #0f172a;
        }

        .preview-frame iframe {
            width: 100%;
            height: 100%;
            border: none;
            transform-origin: top left;
        }

        .preview-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, transparent 60%, rgba(15, 23, 42, 0.8) 100%);
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .card:hover .preview-overlay {
            opacity: 1;
        }

        /* Tags */
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            padding: 16px 24px;
            border-top: 1px solid #334155;
        }

        .tag {
            padding: 6px 12px;
            background: rgba(59, 130, 246, 0.1);
            border: 1px solid rgba(59, 130, 246, 0.3);
            border-radius: 20px;
            font-size: 11px;
            color: #60a5fa;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }

        /* Footer */
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 40px 20px;
            text-align: center;
        }

        .footer-content {
            max-width: 800px;
            margin: 0 auto;
        }

        .footer p {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 16px;
        }

        .footer-links {
            display: flex;
            justify-content: center;
            gap: 24px;
        }

        .footer-links a {
            color: #94a3b8;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: #3b82f6;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            grid-column: 1 / -1;
        }

        .empty-state i {
            font-size: 64px;
            color: #334155;
            margin-bottom: 20px;
        }

        .empty-state h3 {
            font-size: 24px;
            margin-bottom: 8px;
        }

        .empty-state p {
            color: #64748b;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header h1 {
                font-size: 28px;
            }

            .header p {
                font-size: 16px;
            }

            .stats {
                gap: 24px;
            }

            .stat-value {
                font-size: 24px;
            }

            .controls {
                padding: 20px;
            }

            .container {
                padding: 0 20px 40px;
            }

            .grid {
                grid-template-columns: 1fr;
            }

            .preview-frame {
                height: 400px;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
        }

        ::-webkit-scrollbar-track {
            background: #0f172a;
        }

        ::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #475569;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-id-card"></i></div>
                <span class="logo-text">BizBio</span>
            </div>
            <h1>Digital Business Card Templates</h1>
            <p>Choose from our professionally designed templates to create your perfect digital business card. Each template is fully responsive and customizable.</p>
            <div class="stats">
                <div class="stat">
                    <div class="stat-value"><?= $templateCount ?></div>
                    <div class="stat-label">Templates</div>
                </div>
                <div class="stat">
                    <div class="stat-value">100%</div>
                    <div class="stat-label">Responsive</div>
                </div>
                <div class="stat">
                    <div class="stat-value">Free</div>
                    <div class="stat-label">To Use</div>
                </div>
            </div>
        </div>
    </header>

    <div class="controls">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="search" placeholder="Search templates...">
        </div>
        <div class="view-toggle">
            <button class="view-btn active" data-view="normal" title="Normal View">
                <i class="fas fa-th-large"></i>
            </button>
            <button class="view-btn" data-view="large" title="Large View">
                <i class="fas fa-square"></i>
            </button>
        </div>
    </div>

    <div class="container">
        <div class="grid" id="grid">
            <?php if (empty($files)): ?>
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <h3>No Templates Found</h3>
                    <p>Make sure your template files follow the naming convention: 01-template-name.html</p>
                </div>
            <?php else: ?>
                <?php foreach ($files as $file):
                    $info = getTemplateInfo($file, $templateStyles);
                ?>
                <div class="card" data-name="<?= htmlspecialchars(strtolower($info['name'])) ?>" data-tags="<?= htmlspecialchars(implode(' ', $info['tags'])) ?>">
                    <div class="card-header">
                        <div class="card-info">
                            <div class="card-number"><?= htmlspecialchars($info['num']) ?></div>
                            <div class="card-title">
                                <h3><?= htmlspecialchars($info['name']) ?></h3>
                                <span><?= htmlspecialchars($file) ?></span>
                            </div>
                        </div>
                        <div class="card-actions">
                            <a href="<?= htmlspecialchars($file) ?>" target="_blank" class="card-btn" title="Open in New Tab">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                            <a href="<?= htmlspecialchars($file) ?>" class="card-btn primary" title="Preview">
                                <i class="fas fa-eye"></i>
                            </a>
                        </div>
                    </div>
                    <div class="preview-frame">
                        <iframe src="<?= htmlspecialchars($file) ?>" loading="lazy" title="<?= htmlspecialchars($info['name']) ?>"></iframe>
                        <div class="preview-overlay"></div>
                    </div>
                    <div class="tags">
                        <?php foreach ($info['tags'] as $tag): ?>
                            <span class="tag"><?= htmlspecialchars($tag) ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <footer class="footer">
        <div class="footer-content">
            <p>Digital Business Card Templates by BizBio</p>
            <div class="footer-links">
                <a href="#"><i class="fab fa-github"></i> GitHub</a>
                <a href="#"><i class="fas fa-book"></i> Documentation</a>
                <a href="#"><i class="fas fa-envelope"></i> Contact</a>
            </div>
        </div>
    </footer>

    <script>
        // Search functionality
        document.getElementById('search').addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            document.querySelectorAll('.card').forEach(card => {
                const name = card.dataset.name || '';
                const tags = card.dataset.tags || '';
                const matches = name.includes(query) || tags.includes(query);
                card.classList.toggle('hidden', !matches);
            });
        });

        // View toggle
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const grid = document.getElementById('grid');
                grid.classList.toggle('large', btn.dataset.view === 'large');
            });
        });
    </script>
</body>
</html>
