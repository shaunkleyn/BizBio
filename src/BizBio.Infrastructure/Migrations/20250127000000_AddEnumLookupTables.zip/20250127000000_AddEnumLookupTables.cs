//using Microsoft.EntityFrameworkCore.Metadata;
//using Microsoft.EntityFrameworkCore.Migrations;

//#nullable disable

//namespace BizBio.Infrastructure.Migrations
//{
//    /// <inheritdoc />
//    public partial class AddEnumLookupTables : Migration
//    {
//        /// <inheritdoc />
//        protected override void Up(MigrationBuilder migrationBuilder)
//        {
//            // Step 1: Create all lookup tables
//            migrationBuilder.CreateTable(
//                name: "ProductLines",
//                columns: table => new
//                {
//                    Id = table.Column<int>(type: "int", nullable: false)
//                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
//                    Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
//                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
//                    SortOrder = table.Column<int>(type: "int", nullable: false),
//                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_ProductLines", x => x.Id);
//                });

//            migrationBuilder.CreateTable(
//                name: "SubscriptionStatuses",
//                columns: table => new
//                {
//                    Id = table.Column<int>(type: "int", nullable: false)
//                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
//                    Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
//                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
//                    SortOrder = table.Column<int>(type: "int", nullable: false),
//                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_SubscriptionStatuses", x => x.Id);
//                });

//            migrationBuilder.CreateTable(
//                name: "BillingCycles",
//                columns: table => new
//                {
//                    Id = table.Column<int>(type: "int", nullable: false)
//                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
//                    Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
//                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
//                    SortOrder = table.Column<int>(type: "int", nullable: false),
//                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_BillingCycles", x => x.Id);
//                });

//            migrationBuilder.CreateTable(
//                name: "TableCategories",
//                columns: table => new
//                {
//                    Id = table.Column<int>(type: "int", nullable: false)
//                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
//                    Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
//                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
//                    SortOrder = table.Column<int>(type: "int", nullable: false),
//                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_TableCategories", x => x.Id);
//                });

//            migrationBuilder.CreateTable(
//                name: "NFCTagTypes",
//                columns: table => new
//                {
//                    Id = table.Column<int>(type: "int", nullable: false)
//                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
//                    Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
//                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
//                    SortOrder = table.Column<int>(type: "int", nullable: false),
//                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_NFCTagTypes", x => x.Id);
//                });

//            migrationBuilder.CreateTable(
//                name: "NFCTagStatuses",
//                columns: table => new
//                {
//                    Id = table.Column<int>(type: "int", nullable: false)
//                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
//                    Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
//                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
//                    SortOrder = table.Column<int>(type: "int", nullable: false),
//                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_NFCTagStatuses", x => x.Id);
//                });

//            migrationBuilder.CreateTable(
//                name: "DeviceTypes",
//                columns: table => new
//                {
//                    Id = table.Column<int>(type: "int", nullable: false)
//                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
//                    Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
//                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
//                    SortOrder = table.Column<int>(type: "int", nullable: false),
//                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_DeviceTypes", x => x.Id);
//                });

//            // Step 2: Create unique indexes on Name columns
//            migrationBuilder.CreateIndex(name: "IX_ProductLines_Name", table: "ProductLines", column: "Name", unique: true);
//            migrationBuilder.CreateIndex(name: "IX_SubscriptionStatuses_Name", table: "SubscriptionStatuses", column: "Name", unique: true);
//            migrationBuilder.CreateIndex(name: "IX_BillingCycles_Name", table: "BillingCycles", column: "Name", unique: true);
//            migrationBuilder.CreateIndex(name: "IX_TableCategories_Name", table: "TableCategories", column: "Name", unique: true);
//            migrationBuilder.CreateIndex(name: "IX_NFCTagTypes_Name", table: "NFCTagTypes", column: "Name", unique: true);
//            migrationBuilder.CreateIndex(name: "IX_NFCTagStatuses_Name", table: "NFCTagStatuses", column: "Name", unique: true);
//            migrationBuilder.CreateIndex(name: "IX_DeviceTypes_Name", table: "DeviceTypes", column: "Name", unique: true);

//            // Step 3: Seed lookup tables with enum values
//            // ProductLines
//            migrationBuilder.InsertData(table: "ProductLines", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Professional", null, 1, true });
//            migrationBuilder.InsertData(table: "ProductLines", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Menu", null, 2, true });
//            migrationBuilder.InsertData(table: "ProductLines", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Retail", null, 3, true });

//            // SubscriptionStatuses
//            migrationBuilder.InsertData(table: "SubscriptionStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Active", null, 1, true });
//            migrationBuilder.InsertData(table: "SubscriptionStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Cancelled", null, 2, true });
//            migrationBuilder.InsertData(table: "SubscriptionStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Paused", null, 3, true });
//            migrationBuilder.InsertData(table: "SubscriptionStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Expired", null, 4, true });
//            migrationBuilder.InsertData(table: "SubscriptionStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Trial", null, 5, true });

//            // BillingCycles
//            migrationBuilder.InsertData(table: "BillingCycles", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Monthly", null, 1, true });
//            migrationBuilder.InsertData(table: "BillingCycles", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Annual", null, 2, true });

//            // TableCategories
//            migrationBuilder.InsertData(table: "TableCategories", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Regular", null, 1, true });
//            migrationBuilder.InsertData(table: "TableCategories", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "VIP", null, 2, true });
//            migrationBuilder.InsertData(table: "TableCategories", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Window", null, 3, true });
//            migrationBuilder.InsertData(table: "TableCategories", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Patio", null, 4, true });
//            migrationBuilder.InsertData(table: "TableCategories", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Private", null, 5, true });
//            migrationBuilder.InsertData(table: "TableCategories", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Bar", null, 6, true });
//            migrationBuilder.InsertData(table: "TableCategories", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Outdoor", null, 7, true });

//            // NFCTagTypes
//            migrationBuilder.InsertData(table: "NFCTagTypes", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Sticker", null, 1, true });
//            migrationBuilder.InsertData(table: "NFCTagTypes", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Disc", null, 2, true });

//            // NFCTagStatuses
//            migrationBuilder.InsertData(table: "NFCTagStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Active", null, 1, true });
//            migrationBuilder.InsertData(table: "NFCTagStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Inactive", null, 2, true });
//            migrationBuilder.InsertData(table: "NFCTagStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Lost", null, 3, true });
//            migrationBuilder.InsertData(table: "NFCTagStatuses", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Damaged", null, 4, true });

//            // DeviceTypes
//            migrationBuilder.InsertData(table: "DeviceTypes", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Mobile", null, 1, true });
//            migrationBuilder.InsertData(table: "DeviceTypes", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Tablet", null, 2, true });
//            migrationBuilder.InsertData(table: "DeviceTypes", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Desktop", null, 3, true });
//            migrationBuilder.InsertData(table: "DeviceTypes", columns: new[] { "Name", "Description", "SortOrder", "IsActive" },
//                values: new object[] { "Unknown", null, 4, true });

//            // Step 4: Add new FK columns (nullable first to allow data migration)
//            migrationBuilder.AddColumn<int>(name: "ProductLineId", table: "SubscriptionTiers", type: "int", nullable: true);
//            migrationBuilder.AddColumn<int>(name: "StatusId", table: "UserSubscriptions", type: "int", nullable: true);
//            migrationBuilder.AddColumn<int>(name: "BillingCycleId", table: "UserSubscriptions", type: "int", nullable: true);
//            migrationBuilder.AddColumn<int>(name: "TableCategoryId", table: "RestaurantTables", type: "int", nullable: true);
//            migrationBuilder.AddColumn<int>(name: "NFCTagTypeId", table: "RestaurantTables", type: "int", nullable: true);
//            migrationBuilder.AddColumn<int>(name: "NFCTagStatusId", table: "RestaurantTables", type: "int", nullable: true);
//            migrationBuilder.AddColumn<int>(name: "DeviceTypeId", table: "NFCScans", type: "int", nullable: true);

//            // Step 5: Migrate data from string columns to FK columns
//            // SubscriptionTiers.ProductLine -> ProductLineId
//            migrationBuilder.Sql(@"
//                UPDATE SubscriptionTiers st
//                INNER JOIN ProductLines pl ON st.ProductLine = pl.Name
//                SET st.ProductLineId = pl.Id
//            ");

//            // UserSubscriptions.Status -> StatusId
//            migrationBuilder.Sql(@"
//                UPDATE UserSubscriptions us
//                INNER JOIN SubscriptionStatuses ss ON us.Status = ss.Name
//                SET us.StatusId = ss.Id
//            ");

//            // UserSubscriptions.BillingCycle -> BillingCycleId
//            migrationBuilder.Sql(@"
//                UPDATE UserSubscriptions us
//                INNER JOIN BillingCycles bc ON us.BillingCycle = bc.Name
//                SET us.BillingCycleId = bc.Id
//            ");

//            // RestaurantTables.TableCategory -> TableCategoryId
//            migrationBuilder.Sql(@"
//                UPDATE RestaurantTables rt
//                INNER JOIN TableCategories tc ON rt.TableCategory = tc.Name
//                SET rt.TableCategoryId = tc.Id
//            ");

//            // RestaurantTables.NFCTagType -> NFCTagTypeId
//            migrationBuilder.Sql(@"
//                UPDATE RestaurantTables rt
//                INNER JOIN NFCTagTypes ntt ON rt.NFCTagType = ntt.Name
//                SET rt.NFCTagTypeId = ntt.Id
//            ");

//            // RestaurantTables.NFCTagStatus -> NFCTagStatusId
//            migrationBuilder.Sql(@"
//                UPDATE RestaurantTables rt
//                INNER JOIN NFCTagStatuses nts ON rt.NFCTagStatus = nts.Name
//                SET rt.NFCTagStatusId = nts.Id
//            ");

//            // NFCScans.DeviceType -> DeviceTypeId
//            migrationBuilder.Sql(@"
//                UPDATE NFCScans ns
//                INNER JOIN DeviceTypes dt ON ns.DeviceType = dt.Name
//                SET ns.DeviceTypeId = dt.Id
//            ");

//            // Step 6: Make FK columns NOT NULL
//            migrationBuilder.AlterColumn<int>(name: "ProductLineId", table: "SubscriptionTiers", type: "int", nullable: false);
//            migrationBuilder.AlterColumn<int>(name: "StatusId", table: "UserSubscriptions", type: "int", nullable: false);
//            migrationBuilder.AlterColumn<int>(name: "BillingCycleId", table: "UserSubscriptions", type: "int", nullable: false);
//            migrationBuilder.AlterColumn<int>(name: "TableCategoryId", table: "RestaurantTables", type: "int", nullable: false);
//            migrationBuilder.AlterColumn<int>(name: "NFCTagTypeId", table: "RestaurantTables", type: "int", nullable: false);
//            migrationBuilder.AlterColumn<int>(name: "NFCTagStatusId", table: "RestaurantTables", type: "int", nullable: false);
//            migrationBuilder.AlterColumn<int>(name: "DeviceTypeId", table: "NFCScans", type: "int", nullable: false);

//            // Step 7: Drop old indexes on string columns
//            migrationBuilder.DropIndex(name: "IX_SubscriptionTiers_ProductLine", table: "SubscriptionTiers");
//            migrationBuilder.DropIndex(name: "IX_UserSubscriptions_Status", table: "UserSubscriptions");

//            // Step 8: Drop old string columns
//            migrationBuilder.DropColumn(name: "ProductLine", table: "SubscriptionTiers");
//            migrationBuilder.DropColumn(name: "Status", table: "UserSubscriptions");
//            migrationBuilder.DropColumn(name: "BillingCycle", table: "UserSubscriptions");
//            migrationBuilder.DropColumn(name: "TableCategory", table: "RestaurantTables");
//            migrationBuilder.DropColumn(name: "NFCTagType", table: "RestaurantTables");
//            migrationBuilder.DropColumn(name: "NFCTagStatus", table: "RestaurantTables");
//            migrationBuilder.DropColumn(name: "DeviceType", table: "NFCScans");

//            // Step 9: Create indexes on new FK columns
//            migrationBuilder.CreateIndex(name: "IX_SubscriptionTiers_ProductLineId", table: "SubscriptionTiers", column: "ProductLineId");
//            migrationBuilder.CreateIndex(name: "IX_UserSubscriptions_StatusId", table: "UserSubscriptions", column: "StatusId");
//            migrationBuilder.CreateIndex(name: "IX_UserSubscriptions_BillingCycleId", table: "UserSubscriptions", column: "BillingCycleId");
//            migrationBuilder.CreateIndex(name: "IX_RestaurantTables_TableCategoryId", table: "RestaurantTables", column: "TableCategoryId");
//            migrationBuilder.CreateIndex(name: "IX_RestaurantTables_NFCTagTypeId", table: "RestaurantTables", column: "NFCTagTypeId");
//            migrationBuilder.CreateIndex(name: "IX_RestaurantTables_NFCTagStatusId", table: "RestaurantTables", column: "NFCTagStatusId");
//            migrationBuilder.CreateIndex(name: "IX_NFCScans_DeviceTypeId", table: "NFCScans", column: "DeviceTypeId");

//            // Step 10: Add foreign key constraints
//            migrationBuilder.AddForeignKey(
//                name: "FK_SubscriptionTiers_ProductLines_ProductLineId",
//                table: "SubscriptionTiers",
//                column: "ProductLineId",
//                principalTable: "ProductLines",
//                principalColumn: "Id",
//                onDelete: ReferentialAction.Restrict);

//            migrationBuilder.AddForeignKey(
//                name: "FK_UserSubscriptions_SubscriptionStatuses_StatusId",
//                table: "UserSubscriptions",
//                column: "StatusId",
//                principalTable: "SubscriptionStatuses",
//                principalColumn: "Id",
//                onDelete: ReferentialAction.Restrict);

//            migrationBuilder.AddForeignKey(
//                name: "FK_UserSubscriptions_BillingCycles_BillingCycleId",
//                table: "UserSubscriptions",
//                column: "BillingCycleId",
//                principalTable: "BillingCycles",
//                principalColumn: "Id",
//                onDelete: ReferentialAction.Restrict);

//            migrationBuilder.AddForeignKey(
//                name: "FK_RestaurantTables_TableCategories_TableCategoryId",
//                table: "RestaurantTables",
//                column: "TableCategoryId",
//                principalTable: "TableCategories",
//                principalColumn: "Id",
//                onDelete: ReferentialAction.Restrict);

//            migrationBuilder.AddForeignKey(
//                name: "FK_RestaurantTables_NFCTagTypes_NFCTagTypeId",
//                table: "RestaurantTables",
//                column: "NFCTagTypeId",
//                principalTable: "NFCTagTypes",
//                principalColumn: "Id",
//                onDelete: ReferentialAction.Restrict);

//            migrationBuilder.AddForeignKey(
//                name: "FK_RestaurantTables_NFCTagStatuses_NFCTagStatusId",
//                table: "RestaurantTables",
//                column: "NFCTagStatusId",
//                principalTable: "NFCTagStatuses",
//                principalColumn: "Id",
//                onDelete: ReferentialAction.Restrict);

//            migrationBuilder.AddForeignKey(
//                name: "FK_NFCScans_DeviceTypes_DeviceTypeId",
//                table: "NFCScans",
//                column: "DeviceTypeId",
//                principalTable: "DeviceTypes",
//                principalColumn: "Id",
//                onDelete: ReferentialAction.Restrict);
//        }

//        /// <inheritdoc />
//        protected override void Down(MigrationBuilder migrationBuilder)
//        {
//            // Drop foreign keys
//            migrationBuilder.DropForeignKey(name: "FK_SubscriptionTiers_ProductLines_ProductLineId", table: "SubscriptionTiers");
//            migrationBuilder.DropForeignKey(name: "FK_UserSubscriptions_SubscriptionStatuses_StatusId", table: "UserSubscriptions");
//            migrationBuilder.DropForeignKey(name: "FK_UserSubscriptions_BillingCycles_BillingCycleId", table: "UserSubscriptions");
//            migrationBuilder.DropForeignKey(name: "FK_RestaurantTables_TableCategories_TableCategoryId", table: "RestaurantTables");
//            migrationBuilder.DropForeignKey(name: "FK_RestaurantTables_NFCTagTypes_NFCTagTypeId", table: "RestaurantTables");
//            migrationBuilder.DropForeignKey(name: "FK_RestaurantTables_NFCTagStatuses_NFCTagStatusId", table: "RestaurantTables");
//            migrationBuilder.DropForeignKey(name: "FK_NFCScans_DeviceTypes_DeviceTypeId", table: "NFCScans");

//            // Drop indexes
//            migrationBuilder.DropIndex(name: "IX_SubscriptionTiers_ProductLineId", table: "SubscriptionTiers");
//            migrationBuilder.DropIndex(name: "IX_UserSubscriptions_StatusId", table: "UserSubscriptions");
//            migrationBuilder.DropIndex(name: "IX_UserSubscriptions_BillingCycleId", table: "UserSubscriptions");
//            migrationBuilder.DropIndex(name: "IX_RestaurantTables_TableCategoryId", table: "RestaurantTables");
//            migrationBuilder.DropIndex(name: "IX_RestaurantTables_NFCTagTypeId", table: "RestaurantTables");
//            migrationBuilder.DropIndex(name: "IX_RestaurantTables_NFCTagStatusId", table: "RestaurantTables");
//            migrationBuilder.DropIndex(name: "IX_NFCScans_DeviceTypeId", table: "NFCScans");

//            // Re-add old string columns
//            migrationBuilder.AddColumn<string>(name: "ProductLine", table: "SubscriptionTiers", type: "varchar(255)", nullable: false, defaultValue: "");
//            migrationBuilder.AddColumn<string>(name: "Status", table: "UserSubscriptions", type: "varchar(255)", nullable: false, defaultValue: "");
//            migrationBuilder.AddColumn<string>(name: "BillingCycle", table: "UserSubscriptions", type: "varchar(255)", nullable: false, defaultValue: "");
//            migrationBuilder.AddColumn<string>(name: "TableCategory", table: "RestaurantTables", type: "varchar(255)", nullable: false, defaultValue: "");
//            migrationBuilder.AddColumn<string>(name: "NFCTagType", table: "RestaurantTables", type: "varchar(255)", nullable: false, defaultValue: "");
//            migrationBuilder.AddColumn<string>(name: "NFCTagStatus", table: "RestaurantTables", type: "varchar(255)", nullable: false, defaultValue: "");
//            migrationBuilder.AddColumn<string>(name: "DeviceType", table: "NFCScans", type: "varchar(255)", nullable: false, defaultValue: "");

//            // Migrate data back
//            migrationBuilder.Sql(@"UPDATE SubscriptionTiers st INNER JOIN ProductLines pl ON st.ProductLineId = pl.Id SET st.ProductLine = pl.Name");
//            migrationBuilder.Sql(@"UPDATE UserSubscriptions us INNER JOIN SubscriptionStatuses ss ON us.StatusId = ss.Id SET us.Status = ss.Name");
//            migrationBuilder.Sql(@"UPDATE UserSubscriptions us INNER JOIN BillingCycles bc ON us.BillingCycleId = bc.Id SET us.BillingCycle = bc.Name");
//            migrationBuilder.Sql(@"UPDATE RestaurantTables rt INNER JOIN TableCategories tc ON rt.TableCategoryId = tc.Id SET rt.TableCategory = tc.Name");
//            migrationBuilder.Sql(@"UPDATE RestaurantTables rt INNER JOIN NFCTagTypes ntt ON rt.NFCTagTypeId = ntt.Id SET rt.NFCTagType = ntt.Name");
//            migrationBuilder.Sql(@"UPDATE RestaurantTables rt INNER JOIN NFCTagStatuses nts ON rt.NFCTagStatusId = nts.Id SET rt.NFCTagStatus = nts.Name");
//            migrationBuilder.Sql(@"UPDATE NFCScans ns INNER JOIN DeviceTypes dt ON ns.DeviceTypeId = dt.Id SET ns.DeviceType = dt.Name");

//            // Drop FK columns
//            migrationBuilder.DropColumn(name: "ProductLineId", table: "SubscriptionTiers");
//            migrationBuilder.DropColumn(name: "StatusId", table: "UserSubscriptions");
//            migrationBuilder.DropColumn(name: "BillingCycleId", table: "UserSubscriptions");
//            migrationBuilder.DropColumn(name: "TableCategoryId", table: "RestaurantTables");
//            migrationBuilder.DropColumn(name: "NFCTagTypeId", table: "RestaurantTables");
//            migrationBuilder.DropColumn(name: "NFCTagStatusId", table: "RestaurantTables");
//            migrationBuilder.DropColumn(name: "DeviceTypeId", table: "NFCScans");

//            // Re-create indexes on string columns
//            migrationBuilder.CreateIndex(name: "IX_SubscriptionTiers_ProductLine", table: "SubscriptionTiers", column: "ProductLine");
//            migrationBuilder.CreateIndex(name: "IX_UserSubscriptions_Status", table: "UserSubscriptions", column: "Status");

//            // Drop lookup tables
//            migrationBuilder.DropTable(name: "ProductLines");
//            migrationBuilder.DropTable(name: "SubscriptionStatuses");
//            migrationBuilder.DropTable(name: "BillingCycles");
//            migrationBuilder.DropTable(name: "TableCategories");
//            migrationBuilder.DropTable(name: "NFCTagTypes");
//            migrationBuilder.DropTable(name: "NFCTagStatuses");
//            migrationBuilder.DropTable(name: "DeviceTypes");
//        }
//    }
//}
