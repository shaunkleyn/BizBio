<?php
require __DIR__ . '/../vendor/autoload.php';

use Slim\Factory\AppFactory;

$config = require __DIR__ . '/../config.php';

$app = AppFactory::create();

// Dependency container for DB
$container = $app->getContainer();
$app->getContainer()->set('db', function() use ($config) {
    $db = $config['db'];
    $dsn = "mysql:host={$db['host']};dbname={$db['dbname']};charset={$db['charset']}";
    return new PDO($dsn, $db['user'], $db['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
});

// Include routes
(require __DIR__ . '/../src/routes.php')($app);

$app->run();
