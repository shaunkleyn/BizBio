﻿using BizBio.UI.Models;
using Microsoft.EntityFrameworkCore;

namespace BizBio.UI.Data
{
    public class BizBioDbContext : DbContext
    {
        public BizBioDbContext(DbContextOptions<BizBioDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Profile> Profiles { get; set; }
        public DbSet<Link> Links { get; set; }
        public DbSet<ProfileTheme> ProfileThemes { get; set; }
        public DbSet<QrCode> QrCodes { get; set; }
        public DbSet<QrVisit> QrVisits { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Table names & indexes
            modelBuilder.Entity<Profile>().HasIndex(p => p.Slug).IsUnique();
            modelBuilder.Entity<QrCode>().HasIndex(q => q.CodeIdentifier).IsUnique();
            modelBuilder.Entity<Link>().HasIndex(l => new { l.ProfileId, l.SortOrder });
            modelBuilder.Entity<QrVisit>().HasIndex(v => v.VisitedAt);

            // relationships
            modelBuilder.Entity<Profile>()
                .HasOne(p => p.Theme)
                .WithOne(t => t.Profile)
                .HasForeignKey<ProfileTheme>(t => t.ProfileId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Profile>()
                .HasMany(p => p.Links)
                .WithOne(l => l.Profile)
                .HasForeignKey(l => l.ProfileId)
                .OnDelete(DeleteBehavior.Cascade);

            //modelBuilder.Entity<QrCode>()
            //    .HasMany(q => q.Profile.QrCodes);// note: simple navigation; not strictly required
// Replace this block:
// modelBuilder.Entity<QrCode>()
//     .HasMany(q => q.Profile.QrCodes) // note: simple navigation; not strictly required
//     .WithOne(qc => qc.Profile)
//     .HasForeignKey(qc => qc.ProfileId)
//     .OnDelete(DeleteBehavior.Cascade);

            // With the correct relationship mapping:
modelBuilder.Entity<Profile>()
    .HasMany(p => p.QrCodes)
    .WithOne(qc => qc.Profile)
    .HasForeignKey(qc => qc.ProfileId)
    .OnDelete(DeleteBehavior.Cascade);
                //.WithOne(qc => qc.Profile)
                //.HasForeignKey(qc => qc.ProfileId)
                //.OnDelete(DeleteBehavior.Cascade);

            // seed small sample (optional)
            modelBuilder.Entity<User>().HasData(new User
            {
                UserId = 1,
                FullName = "Shaun Kleyn",
                Email = "shaun@bizbio.co.za",
                PasswordHash = "EXAMPLEHASH",
                IsVerified = true,
                Role = "admin",
                CreatedAt = DateTime.UtcNow
            });
        }
    }
}
