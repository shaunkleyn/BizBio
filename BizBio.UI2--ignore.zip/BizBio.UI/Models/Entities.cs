﻿    // Models/Entities.cs
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;


namespace BizBio.UI.Models
{
        public class User
        {
            [Key]
            public long UserId { get; set; }

            [Required, MaxLength(150)]
            public string FullName { get; set; }

            [Required, MaxLength(150)]
            public string Email { get; set; }

            [Required, MaxLength(255)]
            public string PasswordHash { get; set; }

            public string PhoneNumber { get; set; }
            public bool IsVerified { get; set; } = false;
            public string Role { get; set; } = "client";

            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
            public DateTime? UpdatedAt { get; set; }
            public DateTime? DeletedAt { get; set; }

            public ICollection<Profile> Profiles { get; set; }
        }

        public class Profile
        {
            [Key]
            public long ProfileId { get; set; }

            [Required]
            public long UserId { get; set; }
            public User User { get; set; }

            [Required, MaxLength(50)]
            public string ProfileType { get; set; } // business / personal

            [Required, MaxLength(150)]
            public string DisplayName { get; set; }

            [MaxLength(255)]
            public string Tagline { get; set; }

            public string Bio { get; set; }
            public string LogoUrl { get; set; }
            public string CoverPhotoUrl { get; set; }
            public string ThemeColor { get; set; }

            [MaxLength(100)]
            public string Slug { get; set; }

            public bool IsPublic { get; set; } = true;

            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
            public DateTime? UpdatedAt { get; set; }
            public DateTime? DeletedAt { get; set; }

            public ICollection<Link> Links { get; set; }
            public ProfileTheme Theme { get; set; }
            public ICollection<QrCode> QrCodes { get; set; }
        }

        public class Link
        {
            [Key]
            public long LinkId { get; set; }
            [Required]
            public long ProfileId { get; set; }
            public Profile Profile { get; set; }
            [Required, MaxLength(100)]
            public string Label { get; set; }
            [Required, MaxLength(255)]
            public string Url { get; set; }
            public string Icon { get; set; }
            public int SortOrder { get; set; }
            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
            public DateTime? DeletedAt { get; set; }
        }

        public class ProfileTheme
        {
            [Key]
            public long ThemeId { get; set; }
            [Required]
            public long ProfileId { get; set; }
            public Profile Profile { get; set; }

            [MaxLength(100)]
            public string FontFamily { get; set; }
            [MaxLength(20)]
            public string AccentColor { get; set; }
            [MaxLength(20)]
            public string BackgroundColor { get; set; }
            [MaxLength(20)]
            public string ButtonStyle { get; set; } = "rounded";
            [MaxLength(20)]
            public string LayoutStyle { get; set; } = "classic";
            public string CustomCss { get; set; }
        }

        public class QrCode
        {
            [Key]
            public long QrId { get; set; }
            [Required]
            public long ProfileId { get; set; }
            public Profile Profile { get; set; }

            [Required, MaxLength(100)]
            public string CodeIdentifier { get; set; }

            [Required, MaxLength(255)]
            public string DestinationUrl { get; set; }

            public int ScanCount { get; set; }
            public DateTime? LastScannedAt { get; set; }
            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        }

        public class QrVisit
        {
            [Key]
            public long VisitId { get; set; }

            [Required]
            public long QrId { get; set; }
            public QrCode QrCode { get; set; }

            [Required]
            public long ProfileId { get; set; }
            public Profile Profile { get; set; }

            [MaxLength(45)]
            public string IpAddress { get; set; }

            public string UserAgent { get; set; }
            [MaxLength(255)]
            public string RefererUrl { get; set; }
            [MaxLength(100)]
            public string LocationCountry { get; set; }
            [MaxLength(100)]
            public string LocationCity { get; set; }
            [MaxLength(20)]
            public string DeviceType { get; set; } = "unknown";
            public DateTime VisitedAt { get; set; } = DateTime.UtcNow;
        }

        public class AuditLog
        {
            [Key]
            public long AuditId { get; set; }
            [MaxLength(100)]
            public string TableName { get; set; }
            [MaxLength(10)]
            public string Action { get; set; }
            public long? RowId { get; set; }
            public string ChangedBy { get; set; }
            public DateTime ChangedAt { get; set; } = DateTime.UtcNow;
            public string OldRowJson { get; set; }
            public string NewRowJson { get; set; }
        }
    }
